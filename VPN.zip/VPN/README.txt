Configure an IKEv2 VPN Connection to a WatchGuard Firebox in Windows 8.1/10/11 
===============================================================================

In the same folder as this README file, find the [filename].bat file, which is a Windows script. This script automatically creates a new IKEv2 VPN connection on your device. The .bat file automatically requests Administrator permissions, which are required to install the CA certificate.

You can also manually configure an IKEv2 VPN connection. This README file includes instructions for both automatic and manual configuration.

For operating system support information, see the Operating System Compatibility Matrix in the Fireware Release Notes at https://www.watchguard.com/wgrd-help/documentation/release-notes/fireware.

Note: Mobile IKEv2 clients do not inherit a domain suffix from the Firebox. To manually configure a domain suffix in Windows, see https://watchguardsupport.secure.force.com/publicKB?type=Article&SFDCID=kA10H000000g3X0SAI in the WatchGuard Knowledge Base.

===============================================================================
Automatic Configuration

To automatically add a new IKEv2 VPN connection in Windows:

    1. Download or copy the Windows_8.1_10_11 folder to your device. This folder contains the automatic configuration file and the required CA certificate.
    2. In the Windows_8.1_10_11 folder, double-click the .bat file. 
    3. If a User Account Control dialog box opens, select "Yes." Two PowerShell windows open; one closes automatically.
    4. If your account does not have Administrator permissions, specify the Administrator credentials when prompted. The "Run as Administrator" option is not supported.
    5. In the open PowerShell window, press any key to continue. The setup process completes. 
    6. To find the new VPN connection, select "Settings" > "Network & Internet" > "VPN."
    7. To connect to the VPN, click the VPN connection that you added and click "Connect." 

===============================================================================
Manual Configuration

Note: If you manually configure the client, we recommend that you configure a default-route (full tunnel) VPN. In Windows 10/11, in the IPv4 adapter properties for the IKEv2 VPN connection, verify that "Use default gateway on remote network" is selected. This is the default-route (full tunnel) option. 

To manually add a new IKEv2 VPN connection in Windows 10/11:

    1. In the Windows_8.1_10_11 folder, right-click the rootca.crt file.
    2. Click "Install Certificate." The Certificate Import Wizard appears.
    3. Select the "Local Machine" store location and click "Next."
    4. If a User Account Control dialog box opens that asks whether to allow this app to make changes to your device, select "Yes."
    5. Select "Place all certificates in the following store."
    6. Click "Browse." 
    7. From the Select Certificate Store list, select "Trusted Root Certificate Authorities."
    8. Click "OK" > "Next" > "Finish." 
    9. If a Security Warning dialog box opens that asks whether to install the certificate, select "Yes."
    10. Click the Start button and select "Settings" > "Network & Internet" > "VPN."
    11. Click "Add a VPN connection." On Windows 11, click "Add VPN."
    12. Specify these settings:
        VPN provider: "Windows (built-in)"
        Connection name: [Descriptive name such as "MyCompany IKEv2 VPN"]
        Server name or address: 212.104.156.139
        VPN Type: "IKEv2"
        Type of sign-in info: "User name and password"
        (Optional) To save your username and password for later use, specify those credentials now. 
    13. Click "Save." 
    14. To connect to the VPN, click the VPN connection that you added and click "Connect."

To manually add a new IKEv2 VPN connection in Windows 8.1:

    1. In the Windows_8.1_10_11 folder, right-click the rootca.crt file.
    2. Click "Install Certificate." The Certificate Import Wizard appears.
    3. Select the "Local Machine" store location and click "Next."
    4. If a User Account Control dialog box opens that asks whether to allow this app to make changes to your device, select "Yes."
    5. Select "Place all certificates in the following store."
    6. Click "Browse." 
    7. From the Select Certificate Store list, select "Trusted Root Certificate Authorities."
    8. Click "OK" > "Next" > "Finish." 
    9. If a Security Warning dialog box opens that asks whether to install the certificate, select "Yes."
    10. Click the Start button and select "PC Settings" > "Network" > "VPN."
    11. Click "Add a VPN connection."
    12. Specify these settings:
        VPN provider: "Microsoft"
        Connection name: [Descriptive name such as "MyCompany IKEv2 VPN"]
        Server name or address: 212.104.156.139
        Type of sign-in info: "User name and password" (Optional)
        (Optional) To save your username and password for later use, specify those credentials now. 
    13. Click "Save."
    14. To open the PC Settings page, click the Back button twice.
    15. Click "Control Panel" > "Network and Internet" > "Network and Sharing Center" > "Change Adapter Settings."
    16. Right-click the VPN adapter that you added and click "Properties."
    17. On the "Security" tab, from the "Type of VPN" list, select "IKEv2" and click "OK."
    18. From the "Data encryption" drop-down list, select "Require encryption."
    19. From the Authentication section, select "Use Extensible Authentication Protocol (EAP)."
    20. From the drop-down list, select the EAP-MSCHAP v2 option and click "OK."
    21. In the Windows system tray, click the Internet Access icon.  
    22. To connect to the VPN, click the VPN connection that you added and click "Connect."
    
===============================================================================
WatchGuard provides interoperability instructions to help our customers configure WatchGuard products to work with products created by other organizations. If you need more information or technical support about configuring a non-WatchGuard product, see the documentation and support resources for that product. 
===============================================================================
