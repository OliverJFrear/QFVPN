
function PrintError ($message) {
  Write-Host $message -ForegroundColor Red -BackgroundColor Black
}

function SetIPSecConfiguration () {
  Set-VpnConnectionIPsecConfiguration -ConnectionName 'QFS T40 IKEv2' -AuthenticationTransformConstants 'SHA196' -CipherTransformConstants 'AES256' -DHGroup 'Group14' -EncryptionMethod 'AES256' -IntegrityCheckMethod 'SHA256' -PfsGroup 'None' -Force
}

function AddVPNConnection () {
  try {
    Add-VpnConnection -Name 'QFS T40 IKEv2' -ServerAddress '212.104.156.139' -TunnelType 'IKEv2' -EncryptionLevel 'Required' -AuthenticationMethod Eap -RememberCredential
    SetIPSecConfiguration
    Write-Host "Created the 'QFS T40 IKEv2' VPN connection"
  }   catch {
    PrintError "Error in creating the 'QFS T40 IKEv2' VPN connection!" 
    PrintError $_.Exception.Message
  }
}

function UpdateVPNConnection () {
  try {
    Set-VpnConnection -Name 'QFS T40 IKEv2' -ServerAddress '212.104.156.139' -TunnelType 'IKEv2' -EncryptionLevel 'Required' -AuthenticationMethod Eap     -WarningAction SilentlyContinue
    SetIPSecConfiguration
    Write-Host "Updated the 'QFS T40 IKEv2' VPN connection"
  }   catch {
    PrintError "Error in updating the 'QFS T40 IKEv2' VPN connection!" 
    PrintError $_.Exception.Message
  }
}

$vpn = Get-VpnConnection -Name 'QFS T40 IKEv2' -ErrorAction SilentlyContinue
if ($vpn -and ($vpn.Name -eq 'QFS T40 IKEv2')) {
  PrintError "A VPN connection with the name 'QFS T40 IKEv2' is already configured on your system."
  $message = "Do you want to update the existing 'QFS T40 IKEv2' VPN connection?"
  $yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Updates the 'QFS T40 IKEv2' VPN connection."
  $no = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "Exit without updating."
  $options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
  $result = $host.ui.PromptForChoice('', $message, $options, 0)
  switch ($result) {
    0 {UpdateVPNConnection}
    1 {PrintError "The existing �QFS T40 IKEv2� VPN connection was not updated. Remove or rename the existing VPN connection and run the script again."}
  }
} else {
  AddVPNConnection
}
exit

